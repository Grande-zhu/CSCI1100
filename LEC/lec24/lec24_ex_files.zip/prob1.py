
values = [ -12, 0, 15, -16, -17.3, 8, 4, -5 ]
new_values =  ## Solution code goes here
print(new_values)
